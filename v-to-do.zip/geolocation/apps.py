from django.apps import AppConfig


class GeolocationConfig(AppConfig):
    name = 'geolocation'
    verbose_name = 'Measurement between 2 locations'
